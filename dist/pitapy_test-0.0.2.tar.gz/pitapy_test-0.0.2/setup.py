from setuptools import setup

setup(pbr=True)
