# s.peters_algorithm
Peters Algorithm acts as automatic modular randomized world generator
